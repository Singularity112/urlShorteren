import './App.css';
import ShortenUrlForm from './components/ShortenUrlForm/ShortenUrlForm';

function App() {

  return (
    <div className="container">
      <ShortenUrlForm />
  </div>
  );
}

export default App;
